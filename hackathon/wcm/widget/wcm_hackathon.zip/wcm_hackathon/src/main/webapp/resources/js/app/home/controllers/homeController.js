'use strict'

app.controller('homeController', homeController)

function homeController($stateParams, $http) {

	var vm = this;
	vm.cadastro = {};	
	
	var json = [{
		"numeroFluig": "10",
		"descricao": "Conta de Energia Elétrica",
		"dataVencimento": "17/10/2017",
		"valor": "12560,87",
		"aprovar": ""
	},{
		"numeroFluig": "11",
		"descricao": "Conta de Água",
		"dataVencimento": "17/10/2017",
		"valor": "3254,85",
		"aprovar": ""
	},{
		"numeroFluig": "12",
		"descricao": "Conta Telefonica",
		"dataVencimento": "17/10/2017",
		"valor": "325,10",
		"aprovar": ""
	},{
		"numeroFluig": "13",
		"descricao": "Conta Internet",
		"dataVencimento": "17/10/2017",
		"valor": "160,87",
		"aprovar": ""
	},{
		"numeroFluig": "14",
		"descricao": "Conta Outros",
		"dataVencimento": "17/10/2017",
		"valor": "7120,30",
		"aprovar": ""
	}];
	
	//CHAMA A FUNCAO DE CARREGAR RELATORIO
	carregaRelatorio(json);	
	
	jQuery(document).ready(function() {
		pageSetUp();
		
		var randomScalingFactor = function() {
            return Math.round(Math.random() * 100);
            //return 0;
        };

		// pie chart example
	    var PieConfig = {
	        type: 'pie',
	        data: {
	            datasets: [{
	                data: [
	                    randomScalingFactor(),
	                    randomScalingFactor(),
	                    randomScalingFactor(),
	                    randomScalingFactor(),
	                    randomScalingFactor(),
	                ],
	                backgroundColor: [
	                    "#F7464A",
	                    "#46BFBD",
	                    "#FDB45C",
	                    "#949FB1",
	                    "#4D5360",
	                ],
	            }],
	            labels: [
	                "Fornecedor 01",
	                "Fornecedor 02",
	                "Fornecedor 03",
	                "Fornecedor 04",
	                "Fornecedor 05"
	            ]
	        },
	        options: {
	            responsive: true
	        }
	    };

		window.myPie = new Chart(document.getElementById("pieChart"), PieConfig);
	});
}

//FUNCAO PARA CARREGAR O RELATÓRIO
var carregaRelatorio = function(data){
	
	//FUNCAO DATATABLE
	var oTable = $('#grid').DataTable({
		data: data,
		destroy: true,
		columns: [
			{ data: "numeroFluig"},
			{ data: "descricao"},
			{ data: "dataVencimento"},
			{ data: "valor"}
		],
		"aoColumnDefs": [{
		              "aTargets": [4],
		              "mData": "numeroFluig",
		              "className": "text-center",
		              "mRender": function (data, type, full) {
		            	  return '<a style="width: 100px;" onclick="functionAprovar('+data+', this)" class="btn btn-info" id="aprovar_'+ data + '">Aprovar</a>'+
		            	         '<a style="width: 100px; margin-left: 10px" onclick="functionReprovar('+data+', this)" class="btn btn-danger" id="reprovar_'+ data + '">Reprovar</a>';
		              }
		          }
	      ],
		"order": [ 0, "asc" ],
		//TRADUÇÃO DOS CAMPOS
		"language": {
			"sEmptyTable": "Nenhum registro encontrado",
			"sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
			"sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
			"sInfoFiltered": "(Filtrados de _MAX_ registros)",
			"sInfoPostFix": "",
			"sInfoThousands": ".",
			"sLengthMenu": "_MENU_ resultados por página",
			"sLoadingRecords": "Carregando...",
			"sProcessing": "Processando...",
			"sZeroRecords": "Nenhum registro encontrado",
			"sSearch": "Pesquisar",
			"oPaginate": {
				"sNext": "Próximo",
				"sPrevious": "Anterior",
				"sFirst": "Primeiro",
				"sLast": "Último"
			},
			"oAria": {
				"sSortAscending": ": Ordenar colunas de forma ascendente",
				"sSortDescending": ": Ordenar colunas de forma descendente"
			}
		}
	});
	
	//REMOVE O FILTRO
	$('#grid_filter').remove();
	
	//SE JÁ EXISTIR O FILTRO - REMOVE E ADICIONA NOVAMENTE
	if($("#multifilter").length > 0){
		$("#multifilter").remove();
	}
	
	$("<tr role='row' id='multifilter'></tr>").insertBefore('#grid thead tr');
	
	$('#grid thead th:visible').each(function () {
    var title = $(this).text();
    $("#multifilter").append( '<th class="hasinput"><input  style="width: 100%" type="text" class="form-control rangeDate" placeholder="'+title+'" /><span></span></th>' );
	});
	
	 $("#grid thead th input[type=text]").on( 'keyup change', function () {
		 oTable.column( $(this).parent().index()+':visible' )
         .search( this.value )
         .draw();
	 });
	 
	 $($('#grid_wrapper .row')[2]).css("margin-top", "10px");
	 
}

//FUNCAO APROVAR
var functionAprovar = function(ev, sv){
	console.log('APROVAR --> ' + ev, sv)
	$(sv).parent().html('<label class="badge bg-color-greenLight">APROVADO</label>');
	
}

//FUNCAO REPROVAR
var functionReprovar = function(ev, sv){
	console.log('REPROVAR --> ' + ev, sv)
	$(sv).parent().html('<label class="badge bg-color-red">REPROVADO</label>');
}
